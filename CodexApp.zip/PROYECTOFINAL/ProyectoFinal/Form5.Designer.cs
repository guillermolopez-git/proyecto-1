﻿namespace ProyectoFinal
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.Nombre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Edad = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Nacionalidad = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ClubActual = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Temporada = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.PosicionJuego = new System.Windows.Forms.TextBox();
            this.MinutosJugados = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Goles = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Asistencias = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.GolesPenalti = new System.Windows.Forms.TextBox();
            this.TarjetaAmarilla = new System.Windows.Forms.TextBox();
            this.TarjetaRoja = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.NumeroCamisola = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nombre Completo";
            // 
            // Nombre
            // 
            this.Nombre.BackColor = System.Drawing.Color.Silver;
            this.Nombre.Location = new System.Drawing.Point(141, 117);
            this.Nombre.Name = "Nombre";
            this.Nombre.Size = new System.Drawing.Size(252, 26);
            this.Nombre.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label3.Location = new System.Drawing.Point(483, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Edad";
            // 
            // Edad
            // 
            this.Edad.BackColor = System.Drawing.Color.Silver;
            this.Edad.Location = new System.Drawing.Point(536, 123);
            this.Edad.Name = "Edad";
            this.Edad.Size = new System.Drawing.Size(252, 26);
            this.Edad.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label4.Location = new System.Drawing.Point(5, 260);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Minutos Jugados";
            // 
            // Nacionalidad
            // 
            this.Nacionalidad.BackColor = System.Drawing.Color.LightGray;
            this.Nacionalidad.Location = new System.Drawing.Point(141, 162);
            this.Nacionalidad.Name = "Nacionalidad";
            this.Nacionalidad.Size = new System.Drawing.Size(252, 26);
            this.Nacionalidad.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label5.Location = new System.Drawing.Point(42, 214);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Temporada";
            // 
            // ClubActual
            // 
            this.ClubActual.BackColor = System.Drawing.Color.LightGray;
            this.ClubActual.Location = new System.Drawing.Point(536, 168);
            this.ClubActual.Name = "ClubActual";
            this.ClubActual.Size = new System.Drawing.Size(252, 26);
            this.ClubActual.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label6.Location = new System.Drawing.Point(1, 343);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Tarjetas Amarilla";
            // 
            // Temporada
            // 
            this.Temporada.BackColor = System.Drawing.Color.Silver;
            this.Temporada.Location = new System.Drawing.Point(141, 208);
            this.Temporada.Name = "Temporada";
            this.Temporada.Size = new System.Drawing.Size(252, 26);
            this.Temporada.TabIndex = 11;
            this.Temporada.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label7.Location = new System.Drawing.Point(414, 217);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(116, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "Posición Juego";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label8.Location = new System.Drawing.Point(440, 171);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 20);
            this.label8.TabIndex = 13;
            this.label8.Text = "Club Actual";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(32, 165);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 20);
            this.label9.TabIndex = 14;
            this.label9.Text = "Nacionalidad";
            // 
            // PosicionJuego
            // 
            this.PosicionJuego.BackColor = System.Drawing.Color.Silver;
            this.PosicionJuego.Location = new System.Drawing.Point(536, 211);
            this.PosicionJuego.Name = "PosicionJuego";
            this.PosicionJuego.Size = new System.Drawing.Size(252, 26);
            this.PosicionJuego.TabIndex = 15;
            // 
            // MinutosJugados
            // 
            this.MinutosJugados.BackColor = System.Drawing.Color.Silver;
            this.MinutosJugados.Location = new System.Drawing.Point(141, 254);
            this.MinutosJugados.Name = "MinutosJugados";
            this.MinutosJugados.Size = new System.Drawing.Size(252, 26);
            this.MinutosJugados.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label10.Location = new System.Drawing.Point(479, 257);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 20);
            this.label10.TabIndex = 17;
            this.label10.Text = "Goles";
            // 
            // Goles
            // 
            this.Goles.BackColor = System.Drawing.Color.Silver;
            this.Goles.Location = new System.Drawing.Point(536, 251);
            this.Goles.Name = "Goles";
            this.Goles.Size = new System.Drawing.Size(252, 26);
            this.Goles.TabIndex = 18;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label11.Location = new System.Drawing.Point(42, 301);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 20);
            this.label11.TabIndex = 19;
            this.label11.Text = "Asistencias";
            // 
            // Asistencias
            // 
            this.Asistencias.BackColor = System.Drawing.Color.Silver;
            this.Asistencias.Location = new System.Drawing.Point(141, 295);
            this.Asistencias.Name = "Asistencias";
            this.Asistencias.Size = new System.Drawing.Size(252, 26);
            this.Asistencias.TabIndex = 20;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label12.Location = new System.Drawing.Point(427, 301);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 20);
            this.label12.TabIndex = 21;
            this.label12.Text = "Goles Penalti";
            // 
            // GolesPenalti
            // 
            this.GolesPenalti.BackColor = System.Drawing.Color.Silver;
            this.GolesPenalti.Location = new System.Drawing.Point(536, 295);
            this.GolesPenalti.Name = "GolesPenalti";
            this.GolesPenalti.Size = new System.Drawing.Size(252, 26);
            this.GolesPenalti.TabIndex = 22;
            // 
            // TarjetaAmarilla
            // 
            this.TarjetaAmarilla.BackColor = System.Drawing.Color.Silver;
            this.TarjetaAmarilla.Location = new System.Drawing.Point(141, 343);
            this.TarjetaAmarilla.Name = "TarjetaAmarilla";
            this.TarjetaAmarilla.Size = new System.Drawing.Size(252, 26);
            this.TarjetaAmarilla.TabIndex = 23;
            // 
            // TarjetaRoja
            // 
            this.TarjetaRoja.BackColor = System.Drawing.Color.Silver;
            this.TarjetaRoja.Location = new System.Drawing.Point(536, 343);
            this.TarjetaRoja.Name = "TarjetaRoja";
            this.TarjetaRoja.Size = new System.Drawing.Size(252, 26);
            this.TarjetaRoja.TabIndex = 24;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label13.Location = new System.Drawing.Point(427, 349);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(103, 20);
            this.label13.TabIndex = 25;
            this.label13.Text = "Tarjetas Roja";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.label14.Location = new System.Drawing.Point(-2, 395);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(134, 20);
            this.label14.TabIndex = 26;
            this.label14.Text = "Numero Camisola";
            // 
            // NumeroCamisola
            // 
            this.NumeroCamisola.BackColor = System.Drawing.Color.Silver;
            this.NumeroCamisola.Location = new System.Drawing.Point(138, 389);
            this.NumeroCamisola.Name = "NumeroCamisola";
            this.NumeroCamisola.Size = new System.Drawing.Size(252, 26);
            this.NumeroCamisola.TabIndex = 27;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(431, 388);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 34);
            this.button1.TabIndex = 28;
            this.button1.Text = "Registrar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(649, 385);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 40);
            this.button2.TabIndex = 29;
            this.button2.Text = "Salir";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Green;
            this.pictureBox2.Image = global::ProyectoFinal.Properties.Resources.premieLeague;
            this.pictureBox2.Location = new System.Drawing.Point(2, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(794, 447);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 30;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Ravie", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(203, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(383, 43);
            this.label1.TabIndex = 31;
            this.label1.Text = "Agregar Jugador";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.NumeroCamisola);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.TarjetaRoja);
            this.Controls.Add(this.TarjetaAmarilla);
            this.Controls.Add(this.GolesPenalti);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Asistencias);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Goles);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.MinutosJugados);
            this.Controls.Add(this.PosicionJuego);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Temporada);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ClubActual);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Nacionalidad);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Edad);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Nombre);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox2);
            this.Name = "Form5";
            this.Text = "Form5";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Nombre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Edad;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Nacionalidad;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ClubActual;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Temporada;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox PosicionJuego;
        private System.Windows.Forms.TextBox MinutosJugados;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Goles;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox Asistencias;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox GolesPenalti;
        private System.Windows.Forms.TextBox TarjetaAmarilla;
        private System.Windows.Forms.TextBox TarjetaRoja;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox NumeroCamisola;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
    }
}